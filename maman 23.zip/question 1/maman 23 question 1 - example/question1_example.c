#include <stdio.h>

/* Define a function that matches the signature*/
int* add(int a, int b) {
	int *p = &a;
	*p += b;
	return p;
}

/* Define another function that matches the signature*/
int* subtract(int a, int b) {
	int *p = &a;
	*p -= b;
	return p;
}

int main() {
	/* Declare a pointer to a 2x2 array of pointers to functions*/
	int *(*(*p)[2][2])(int, int);
	int *(*arr[2][2])(int,int);
	int result;

	arr[0][0] = &add;
	arr[0][1] = &subtract;
	/* Assign the address of the function add to the pointer*/
	p = &arr;

	/* Call the function through the pointer*/
	result = *((***(*p))(3, 2));
	printf("Result of addition: %d\n", result);  /* Output: 5*/

	/* Call the function through the pointer*/
	result = *((**(*(*p)+1))(3, 2));
	printf("Result of subtraction: %d\n", result);  /* Output: 1*/

	return 0;
}

