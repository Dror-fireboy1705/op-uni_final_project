/*the program lists many different functions
used to assist with the main program.*/

#include "hash.h"

/*the function searchs a list until it finds
a node which matches the current opened file.
if there is no such node, the funtion returns NULL.
input: the head pointer of a list and the name of the required file
return: a pointer to the node matching the name of file, NULL if there isn't one*/
shows* search(shows *p, char *fname)
{
	if(p->name == NULL)/*if this is first time num appears at all*/
	{
		return p;
	}
	if(!(strcmp(p->name,fname)))/*if this is the first file num appeared in*/
	{
		return p;/*return pointer to list node matching current file*/
	}
	/*find last node in list that fits current file(or get to end of list to make new file)*/
	while(p->next)
	{
		p=p->next;
		if(!(strcmp(p->name,fname)))/*if name matches*/
		{
			return p;/*return pointer to list node matching current file*/
		}
	}
	/*if(!(p->next)) num hasn't appeared yet in this file(reached end of list)*/
	return p;
}

/*the function prints the values stored in the list
in a manner that matches the requirements of maman 23.
input: the head pointer of the list to print
output: each name of a file stored in the list and the amount of appearences in that file*/
void printNum(shows * p)
{
	char *sngl = "time", *mltpl = "times";/*distinct between single appearence and multiple ones*/
	printf("file %s - %d %s", p->name, p->cnt, (p->cnt == 1)? sngl: mltpl);/*print first node according to instructions*/
	while(p->next)/*loop to print every subsequent node(if there are any)*/
	{
		p = p->next;
		printf(", file %s - %d %s", p->name, p->cnt, (p->cnt == 1)? sngl: mltpl);
	}
}

/*the function boots an array of pointers to type
shows by initiallizing each cell and allocating
space to each spot in the array.
input: an array of pointers to type shows and the length of the array
return: 0 if booting was succefull, 1 otherwise*/
int bootArr(shows *arr[], int len)
{
	int i;
	for(i=0; i<len; i++)/*loop to go over each cell in array*/
	{
		arr[i] = (shows *)malloc(sizeof(shows));
		if(arr[i] == NULL)/*check if allocation failed*/
		{
			return 1;/*signal error to stop program*/
		}
	}
	return 0;
}

/*the function frees all the space in array of
type shows, freeing every node in every list
of type shows in every cell
input: an array of pointers to type shows and the length of the array*/
void freeArr(shows *arr[], int len)
{
	shows *p, *q;/*pointers for current and previous nodes in each list*/
	int i;
	for(i=0; i<len; i++)
	{
		p = arr[i];
		if(p->next == NULL)/*no further nodes for num*/
		{
			free(p);
		}
		else
		{
			while(arr[i]->next != NULL)/*keep freeing until reach back to head node*/
			{
				while(p->next != NULL)/*loop to go to last node in list*/
				{
					q = p;/*save previous node pointer*/
					p = p->next;/*advance to next pointer*/
				}
				free(p);/*free last node in list*/
				q->next = NULL;/*erase from list*/
				p = arr[i];/*go back to start of list*/
			}
			free(p);/*free head node after all others have been*/
		}
	}
}
