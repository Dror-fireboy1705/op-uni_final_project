/*the program counts and lists out the amount
of apearences of a number between 0 and 28
in one of the given files.
input: names of files as arguments in the command line
output: an ordered display of the number of apearences of each number (0...28) in each file
return: 0 if program ran successfully, 1 otherwise*/

#include "hash.h"

int main(int argc, char *argv[])
{
	FILE *p;/*pointer for each file*/
	shows *apr[range];/*array with list for each number within range*/
	shows *ptr;/*pointer for specific node in each list*/
	int i, num;/*index for loops and variable for each number just read in file*/
	
	if(argc < minArgs)/*if no files added*/
	{
		fprintf(stderr, "no files submitted at run of program\n");
		return 1;/*stop program and signal error*/
	}
	
	if(bootArr(apr,range))/*booting the array(check in case of allocation failing)*/
	{
		fprintf(stderr, "allocation falied\n");
		return 1;/*stop program and signal error*/
	}
	for(i=1; i<argc; i++)/*go over each file*/
	{
		p = fopen(argv[i],"r");
		
		if(p == NULL)/*if file unopenable*/
		{
			fprintf(stderr, "unusable file name entered\n");
			return 1;/*stop program and signal error*/
		}
		while(fscanf(p,"%d",&num) != EOF)/*read file each number at a time until empty and save appearences in hash table*/
		{
			ptr = search(apr[num], argv[i]);/*find node for current file*/
			if(ptr->name == NULL)/*num hasn't appeared yet*/
			{
				/*boot first node of list for given num*/
				ptr->name = argv[i];
				ptr->cnt = 1;
			}
			else if(!(strcmp(ptr->name, argv[i])))/*num appeared in file*/
			{
				(ptr->cnt)++;/*increase recorded appearences by 1*/
			}
			else/*reached end of list of num and file not found(creat new node for file)*/
			{
				ptr->next = (shows *)malloc(sizeof(shows));
				if(ptr->next == NULL)/*if allocation failed*/
				{
					fprintf(stderr, "allocation failed\n");
					return 1;/*stop program and signal error*/
				}
				/*boot new node of list for given num*/
				ptr->next->name = argv[i];
				ptr->next->cnt = 1;
			}
		}
		
		fclose(p);/*one file open each time*/
	}
	
	for(i=0; i<range; i++) /*print*/
	{
		if(apr[i]->name != NULL)/*check if number appeared at all*/
		{
			printf("%d appears in ", i);
			printNum(apr[i]);
			putchar('\n');
		}
	}
	
	freeArr(apr, range);/*release all allocated space*/
	return 0;
}
