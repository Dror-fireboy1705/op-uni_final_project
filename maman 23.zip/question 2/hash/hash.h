#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define range 29
#define size 256
#define minArgs 2

/*defenition of recursive list for hash table*/
typedef struct list_file
{
	char *name;/*name of each file*/
	int cnt;/*number of appearnces of associated number in file*/
	struct list_file * next;/*pointer to node of next file*/
} shows;


shows* search(shows *, char *);/*input: the head pointer of a list and the name of the required file
				 return: a pointer to the node matching the name of file, NULL if there isn't one*/
void printNum(shows *);/*input: the head pointer of the list to print
			 output: each name of a file stored in the list and the amount of appearences in that file*/
int bootArr(shows* [], int);/*  input: an array of pointers to type shows and the length of the array
				return: 0 if booting was succefull, 1 otherwise*/
void freeArr(shows* [], int);/*input: an array of pointers to type shows and the length of the array*/
